package com.aj.operacionesapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText et1;
    EditText et2;
    TextView tvResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        tvResultado = findViewById(R.id.tvResultado);
    }

    public void suma(View view){
        int resultado = Integer.parseInt(et1.getText().toString()) + Integer.parseInt(et2.getText().toString());
        tvResultado.setText("El resultado es: "+resultado);
    }

    public void resta(View view){
        int resultado = Integer.parseInt(et1.getText().toString()) - Integer.parseInt(et2.getText().toString());
        tvResultado.setText("El resultado es: "+resultado);
    }

    public void multiplicacion(View view){
        int resultado = Integer.parseInt(et1.getText().toString()) * Integer.parseInt(et2.getText().toString());
        tvResultado.setText("El resultado es: "+resultado);
    }

    public void division(View view){
        if(Integer.parseInt(et2.getText().toString()) != 0){
            int resultado = Integer.parseInt(et1.getText().toString()) / Integer.parseInt(et2.getText().toString());
            tvResultado.setText("El resultado es: "+resultado);
        }else{
            tvResultado.setText("ERROR, no se puede dividir entre 0");
        }

    }
}