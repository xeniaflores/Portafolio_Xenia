package com.aj.guia2analisis2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SegundaActividad extends AppCompatActivity {
    private TextView tvNombre;
    private TextView tvSalarioBase;
    private TextView tvSeguro;
    private TextView tvAfp;
    private TextView tvRenta;
    private TextView tvTotalDescuento;
    private TextView tvSalarioNeto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_actividad);

        tvNombre=findViewById(R.id.tvNombre);
        tvSalarioBase=findViewById(R.id.tvSalarioBase);
        tvSeguro=findViewById(R.id.tvSeguro);
        tvAfp=findViewById(R.id.tvAfp);
        tvRenta=findViewById(R.id.tvRenta);
        tvTotalDescuento=findViewById(R.id.tvTotalDescuento);
        tvSalarioNeto=findViewById(R.id.tvSalarioNeto);

        Bundle bundle = getIntent().getExtras();

        String nombre = bundle.getString("nombre");
        String salario = bundle.getString("salario");
        String seguro = bundle.getString("seguro");
        String afp = bundle.getString("afp");
        String renta = bundle.getString("renta");
        String total = bundle.getString("total");
        String neto = bundle.getString("neto");

        tvNombre.setText(nombre);
        tvSalarioBase.setText(salario);
        tvSeguro.setText(seguro);
        tvAfp.setText(afp);
        tvRenta.setText(renta);
        tvTotalDescuento.setText(total);
        tvSalarioNeto.setText(neto);
    }

    public void Cerrar(View view){
        finish();
    }
}