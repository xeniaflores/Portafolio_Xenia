package com.aj.guia2analisis2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText etNombre;
    private EditText etHoras;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etNombre=findViewById(R.id.etNombre);
        etHoras=findViewById(R.id.etHoras);
    }

    public void mostrarResultado(View v){
        String nombre = etNombre.getText().toString();
        int horas = Integer.parseInt(etHoras.getText().toString());
        double salario = horas*8.5;
        double isss=salario*0.02;
        double afp=salario*0.03;
        double renta=salario*0.04;
        double descuento=isss+afp+renta;
        double neto=salario-descuento;

        Intent i = new Intent(this,SegundaActividad.class);
        i.putExtra("nombre","Nombre: "+nombre);
        i.putExtra("salario","Salario base: $"+String.valueOf(salario));
        i.putExtra("seguro","Descuento ISSS (2%): $"+String.valueOf(isss));
        i.putExtra("afp","Descuento AFP(3%): $"+String.valueOf(afp));
        i.putExtra("renta","Descuento Renta(4%): $"+String.valueOf(renta));
        i.putExtra("total","Total descuentos: $"+String.valueOf(descuento));
        i.putExtra("neto","Salario neto: $"+String.valueOf(neto));

        startActivity(i);
    }
}