package com.aj.guia2analisis1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv1 = findViewById(R.id.tv1);
    }

    public void incremento(View view){
        int val = Integer.parseInt(tv1.getText().toString());

        if(val==9){
            val=0;
        }else{
            val++;
        }

        tv1.setText(String.valueOf(val));
    }
}